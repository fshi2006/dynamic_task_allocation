#include "locationudpclient.hpp"

namespace locationudpclient {

    locationudpclient::locationudpclient(const ros::NodeHandle &nh, const ros::NodeHandle &nh_private, std::string node_name):nh_(nh), nh_private_(nh_private),
    node_name(node_name)
    {

        initialize();
    }

    void locationudpclient::initialize() {

        initSocket();

        pub_second = nh_.advertise<multi_vehicle_msgs::Lo_Location>("bigrobot2/Lo_Location",1000);
        pub_third  = nh_.advertise<multi_vehicle_msgs::Lo_Location>("bigrobot3/Lo_Location",1000);
        pub_forth  = nh_.advertise<multi_vehicle_msgs::Lo_Location>("bigrobot4/Lo_Location",1000);
        pub_fifth  = nh_.advertise<multi_vehicle_msgs::Lo_Location>("bigrobot5/Lo_Location",1000);
        pub_sixth  = nh_.advertise<multi_vehicle_msgs::Lo_Location>("bigrobot1/Lo_Location",1000);
        pub_all_location = nh_.advertise<nav_msgs::Path>("robot_location_all",1000);
        loop_timer_ = nh_.createTimer(ros::Duration(0.01), boost::bind(&locationudpclient::timerCb, this));

    }

    bool locationudpclient::initSocket() {

        this->UdpNetSocket =  socket(PF_INET, SOCK_DGRAM, 0);
        if(this->UdpNetSocket == -1){
            printf("socket fail\n");
            return false;
        } else{
            std::cout << "create UdpNetSocket succeed!" << std::endl;
        }

        int set = 1;
        setsockopt(this->UdpNetSocket, SOL_SOCKET, SO_REUSEADDR, &set, sizeof(int));
        memset(&recvAddr, 0, sizeof(struct sockaddr_in));
        recvAddr.sin_family = AF_INET;
        recvAddr.sin_port = htons(4002);
        recvAddr.sin_addr.s_addr = INADDR_ANY;
        // 必须绑定，否则无法监听
        if(bind(this->UdpNetSocket, (struct sockaddr *)&recvAddr, sizeof(struct sockaddr)) == -1){
            printf("bind fail\n");
            return -1;
        }

        std::cout << "Listen the broadcast haved finished. " <<std::endl;

        return true;
    }


    void locationudpclient::timerCb(){

        nav_msgs::Path robot_poses_all;
		robot_poses_all.header.frame_id = "robot_poses";
        recvmsgs();
        for(unsigned int i=0; i<robot_location_all.size();i++){
			//std::cout << Aco_Init.TotalTaskNode.at(i).x << " ";
			geometry_msgs::PoseStamped tempose;
            tempose.header.frame_id = robot_location_all[i].ID;
			tempose.pose.position.x = robot_location_all[i].robot_x;
			tempose.pose.position.y = robot_location_all[i].robot_y ;
			robot_poses_all.poses.push_back(tempose);
			}
        pub_all_location.publish(robot_poses_all);
    }


    void locationudpclient::recvmsgs(){

        socklen_t addrLen = sizeof(struct sockaddr_in);

        int recvbytes = recvfrom(this->UdpNetSocket, this->recvbuf, BUF_SIZE, 0,
                               (struct sockaddr *)&recvAddr, &addrLen);

        if(recvbytes != -1)
        {
            recvbuf[recvbytes] = '\0';
            printf("receive a broadCast messgse:%s\n", recvbuf);
            //std::cout<<"receive a broadCast messgse:"<<recvbuf<<std::endl;
        }
        else{
            printf("recvfrom fail\n");
        }

        for(int i = 0; i < recvbytes; i++){
            if(recvbuf[i] == 'a' && recvbuf[i+1] == 'a'){
                switch (recvbuf[i+2]){

                    case '2': recvData(&gps_second,recvbuf, i+3);pub_second.publish(msg);
                        break;
                    case '3': recvData(&gps_third, recvbuf, i+3);pub_third.publish(msg);
                        break;
                    case '4': recvData(&gps_forth, recvbuf, i+3);pub_forth.publish(msg);
                        break;
                    case '5': recvData(&gps_fifth, recvbuf, i+3);pub_fifth.publish(msg);
                        break;
                    case '1': recvData(&gps_sixth, recvbuf, i+3);pub_sixth.publish(msg);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    int locationudpclient::recvData(GpsMsg *data, char *buf, int i) {

        int index =i;
        memcpy(data, buf+index, sizeof(*data));
	    msg.position.x = data->longitude;
        msg.position.y = data->latitude;
        robot_location robot_tmp;
        robot_tmp.ID = buf[i-1];
        robot_tmp.robot_x = data->longitude;
        robot_tmp.robot_y = data->latitude;
        msg.position.z = data->altitude;
        msg.heading  = data->heading;
        msg.roll = data->roll;
        msg.pitch = data->pitch;
        msg.re_position.x = data->dlongitude;
        msg.re_position.y = data->dlatitude;
        msg.re_position.z = data->daltitude;
        msg.GNSS_status = data->GNSS_status;
        robot_location_all.push_back(robot_tmp);
	return index;
    }

}



int main(int argc, char **argv) {

        std::string node_name = "locationudpclient_node";
        ros::init(argc, argv, node_name);
        ros::NodeHandle nh("");
        ros::NodeHandle nh_private("~");
        locationudpclient::locationudpclient recv(nh, nh_private, node_name);
        ROS_INFO("Initialized recv node.");
        ros::spin();
}
